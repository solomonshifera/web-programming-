<?php
include "header.php";
include "sidebar.php";

if(isset($_POST['save'])){
mysqli_query($conn,"INSERT INTO students(name,Reg_no,dept)
VALUES('$_POST[name]','$_POST[reg]','$_POST[dept]')");
echo "Student Added";
}
?>

<form method="post" class="form-card">
<h4>Add Student</h4>
<input name="name" class="form-control" placeholder="Student Name">
<input name="reg" class="form-control mt-2" placeholder="Reg No">
<input name="dept" class="form-control mt-2" placeholder="Department">
<button name="save" class="btn btn-primary mt-3">Save</button>
</form>

<?php include "footer.php"; ?>
