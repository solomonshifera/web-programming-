<?php
include "header.php";
include "sidebar.php";

// Fetch issued books
$issued = mysqli_query($conn,"
SELECT issue_book.id AS issue_id, students.name, books.book_name, books.id AS bookid 
FROM issue_book
JOIN students ON students.id = issue_book.student_id
JOIN books ON books.id = issue_book.book_id
WHERE status='issued'
");

// Handle return
if(isset($_POST['return'])){
    if(isset($_POST['id'], $_POST['bid'])){
        $issue_id = mysqli_real_escape_string($conn, $_POST['id']);
        $book_id = mysqli_real_escape_string($conn, $_POST['bid']);

        // Update issue_book table
        $update_issue = "UPDATE issue_book 
                         SET status='returned', return_date=CURDATE() 
                         WHERE id='$issue_id'";
        mysqli_query($conn, $update_issue);

        // Update books quantity
        $update_book = "UPDATE books SET quantity = quantity + 1 WHERE id='$book_id'";
        mysqli_query($conn, $update_book);

        echo "<script>alert('Book Returned'); window.location='returned.php';</script>";
        exit;
    } else {
        echo "<script>alert('Invalid data!'); window.location='returned.php';</script>";
        exit;
    }
}
?>

<div class="form-card">
<h4>Return Book</h4>

<form method="post">
<select name="id" class="form-control" required>
    <option value="">-- Select Student & Book --</option>
    <?php while($i=mysqli_fetch_assoc($issued)){ ?>
        <option value="<?=$i['issue_id'];?>" data-bid="<?=$i['bookid'];?>">
            <?=$i['name'];?> — <?=$i['book_name'];?>
        </option>
    <?php } ?>
</select>

<!-- hidden input for book id -->
<input type="hidden" name="bid" id="book_id">

<button class="btn btn-success mt-3" name="return">Return</button>
</form>
</div>

<script>
// Automatically set hidden input 'bid' based on selected option
const select = document.querySelector('select[name="id"]');
const bookInput = document.getElementById('book_id');

select.addEventListener('change', function(){
    const selectedOption = this.options[this.selectedIndex];
    bookInput.value = selectedOption.getAttribute('data-bid');
});
</script>

<?php include "footer.php"; ?>
