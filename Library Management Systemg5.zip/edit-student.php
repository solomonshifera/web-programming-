<?php 
include "header.php";
include "sidebar.php";

$students = mysqli_query($conn,"SELECT * FROM students ORDER BY id DESC");
?>

<div class="table-box">
<h4>STUDENT LIST</h4>

<table class="table table-bordered">
<tr>
  <th>#</th>
  <th>Name</th>
  <th>Reg No</th>
  <th>Department</th>
  <th>Action</th>
</tr>

<?php $i=1; while($row=mysqli_fetch_assoc($students)){ ?>
<tr>
<td><?php echo $i++; ?></td>
<td><?php echo $row['name']; ?></td>
<td><?php echo $row['reg_no']; ?></td>
<td><?php echo $row['dept']; ?></td>

<td>
  <a href="edit-student.php?id=<?php echo $row['id']; ?>" class="btn btn-sm btn-primary">
    Edit
  </a>

  <a href="delete-student.php?id=<?php echo $row['id']; ?>" 
     class="btn btn-sm btn-danger"
     onclick="return confirm('Are you sure you want to delete this student?');">
    Delete
  </a>
</td>

</tr>
<?php } ?>
</table>

</div>

<?php include "footer.php"; ?>
