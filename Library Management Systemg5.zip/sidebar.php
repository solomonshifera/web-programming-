<div class="sidebar">
<a href="index.php">🏠 Dashboard</a>
<a href="add_book.php">➕ Add Book</a>
<a href="view_books.php">📚 View Books</a>
<a href="add_student.php">👨‍🎓 Add Student</a>
<a href="view_students.php">📋 View Students</a>
<a href="issue_book.php">📖 Issue Book</a>
<a href="returned.php">📥 Return Book</a>
<a href="logout.php">🚪 Logout</a>
</div>

<div class="content">
