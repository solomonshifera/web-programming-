<?php include "auth.php"; ?>
<?php include "db.php"; ?>
<!DOCTYPE html>
<html>
<head>
<title>Digital Library</title>
<link rel="stylesheet" href="style.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="top-bar">
   <h3>Digital<span>Library</span></h3>
   <div class="admin-box"><?php echo $_SESSION['user']; ?></div>
</div>
<div class="wrapper">
