<?php
$conn = mysqli_connect("localhost","root","","library_solomondb",3307);

if(!$conn){
   die("Database Connection Failed: " . mysqli_connect_error());
}
?>
