<?php
include "header.php";
include "sidebar.php";

$students = mysqli_query($conn,"SELECT * FROM students");
$books = mysqli_query($conn,"SELECT * FROM books WHERE quantity>0");

if(isset($_POST['issue'])){
mysqli_query($conn,"INSERT INTO issue_book(student_id,book_id,issue_date,status)
VALUES('$_POST[student]','$_POST[book]',CURDATE(),'issued')");

mysqli_query($conn,"UPDATE books SET quantity=quantity-1 WHERE id=$_POST[book]");

echo "<script>alert('Book Issued');</script>";
}
?>

<div class="form-card">
<h4>Issue Book</h4>

<form method="post">

<select name="student" class="form-control">
<?php while($s=mysqli_fetch_assoc($students)){ ?>
<option value="<?=$s['id'];?>"><?=$s['name'];?></option>
<?php } ?>
</select>

<select name="book" class="form-control mt-2">
<?php while($b=mysqli_fetch_assoc($books)){ ?>
<option value="<?=$b['id'];?>"><?=$b['book_name'];?></option>
<?php } ?>
</select>

<button class="btn btn-primary mt-3" name="issue">Issue</button>

</form>
</div>

<?php include "footer.php"; ?>
