<?php 
include "header.php"; 
include "sidebar.php"; 

$book_count = mysqli_fetch_row(mysqli_query($conn,"SELECT COUNT(*) FROM books"))[0];
$student_count = mysqli_fetch_row(mysqli_query($conn,"SELECT COUNT(*) FROM students"))[0];
$issued_count = mysqli_fetch_row(mysqli_query($conn,"SELECT COUNT(*) FROM issue_book WHERE status='issued'"))[0];
$returned_count = mysqli_fetch_row(mysqli_query($conn,"SELECT COUNT(*) FROM issue_book WHERE status='returned'"))[0];
?>

<h3>📘 Digital Library Dashboard</h3>

<div class="row">

<div class="col-md-3">
  <div class="form-card">
    <h4>Total Books</h4>
    <h2><?php echo $book_count; ?></h2>
  </div>
</div>

<div class="col-md-3">
  <div class="form-card">
    <h4>Total Students</h4>
    <h2><?php echo $student_count; ?></h2>
  </div>
</div>

<div class="col-md-3">
  <div class="form-card">
    <h4>Issued</h4>
    <h2><?php echo $issued_count; ?></h2>
  </div>
</div>

<div class="col-md-3">
  <div class="form-card">
    <h4>Returned</h4>
    <h2><?php echo $returned_count; ?></h2>
  </div>
</div>

</div>

<br>

<div class="form-card">
<h4>Quick Actions</h4>

<a class="btn btn-primary" href="add_book.php">➕ Add Book</a>
<a class="btn btn-success" href="view_books.php">📚 View Books</a>
<a class="btn btn-info" href="add_student.php">👨‍🎓 Add Student</a>
<a class="btn btn-warning" href="view_students.php">📋 View Students</a>
<a class="btn btn-dark" href="issue_book.php">📖 Issue Book</a>
<a class="btn btn-secondary" href="returned.php">📥 Return Book</a>

</div>

<?php include "footer.php"; ?>
