<?php 
include "header.php";
include "sidebar.php";

$books = mysqli_query($conn,"SELECT * FROM books ORDER BY id DESC");
?>

<div class="table-box">
<h4>BOOK LIST</h4>

<table class="table table-bordered">
<tr>
<th>#</th>
<th>Photo</th>
<th>Book Name</th>
<th>Author</th>
<th>Branch</th>
<th>Qty</th>
<th>Action</th>
</tr>

<?php $i=1; while($r=mysqli_fetch_assoc($books)){ ?>

<tr>
<td><?php echo $i++; ?></td>
<td><img src="uploads/<?php echo $r['photo'];?>" width="60"></td>
<td><?php echo $r['book_name'];?></td>
<td><?php echo $r['author'];?></td>
<td><?php echo $r['branch'];?></td>
<td><?php echo $r['quantity'];?></td>
<td>
<a class="btn btn-warning btn-sm" href="edit_book.php?id=<?php echo $r['id'];?>">Edit</a>
<a class="btn btn-danger btn-sm" href="delete_book.php?id=<?php echo $r['id'];?>" onclick="return confirm('Delete?')">Delete</a>
</td>
</tr>

<?php } ?>
</table>
</div>

<?php include "footer.php"; ?>
