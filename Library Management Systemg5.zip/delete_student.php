<?php
include "db.php";

// Check if id is passed
if(isset($_GET['id'])){
    $id = $_GET['id'];

    // Prevent SQL injection
    $id = mysqli_real_escape_string($conn, $id);

    // Check if student has issued books
    $check = mysqli_query($conn,"SELECT * FROM issue_book WHERE student_id='$id' AND status='issued'");

    if(mysqli_num_rows($check) > 0){
        echo "<script>
        alert('This student still has an issued book. Return it first!');
        window.location='view_students.php';
        </script>";
        exit;
    }

    // Delete student if no issued books
    if(mysqli_query($conn,"DELETE FROM students WHERE id='$id'")){
        echo "<script>
        alert('Student Deleted Successfully');
        window.location='view_students.php';
        </script>";
    } else {
        echo "<script>
        alert('Error deleting student!');
        window.location='view_students.php';
        </script>";
    }

} else {
    echo "<script>
    alert('No student ID provided!');
    window.location='view_students.php';
    </script>";
}
?>
