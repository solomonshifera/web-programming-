<?php
include "db.php";
session_start();

if(isset($_POST['login'])){
 $u=$_POST['user'];
 $p=md5($_POST['pass']);

 $q=mysqli_query($conn,"SELECT * FROM users WHERE username='$u' AND password='$p'");
 if(mysqli_num_rows($q)==1){
   $_SESSION['user']=$u;
   header("location:index.php");
 } else $msg="Invalid Login!";
}
?>

<form method="post">
<h3>Login</h3>
<input name="user" placeholder="Username"><br>
<input type="password" name="pass" placeholder="Password"><br>
<button name="login">Login</button>
<?php if(isset($msg)) echo $msg; ?>
</form>
