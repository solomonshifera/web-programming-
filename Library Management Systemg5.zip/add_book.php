<?php 
include "header.php";
include "sidebar.php";

if(isset($_POST['save'])){

$book = $_POST['book_name'];
$author = $_POST['author'];
$pub = $_POST['publication'];
$branch = $_POST['branch'];
$qty = $_POST['quantity'];

$photo = $_FILES['photo']['name'];
$tmp = $_FILES['photo']['tmp_name'];

move_uploaded_file($tmp,"uploads/".$photo);

mysqli_query($conn,"INSERT INTO books(book_name,author,publication,branch,quantity,photo)
VALUES('$book','$author','$pub','$branch','$qty','$photo')");

echo "<script>alert('Book Added Successfully');</script>";
}
?>

<div class="form-card">
<h4>ADD NEW BOOK</h4>
<form method="post" enctype="multipart/form-data">

<label>Book Name</label>
<input type="text" name="book_name" class="form-control" required>

<label>Author</label>
<input type="text" name="author" class="form-control" required>

<label>Publication</label>
<input type="text" name="publication" class="form-control">

<label>Branch</label>
<select name="branch" class="form-control">
<option>IT</option>
<option>CS</option>
<option>Engineering</option>
<option>Other</option>
</select>

<label>Quantity</label>
<input type="number" name="quantity" class="form-control">

<label>Book Photo</label>
<input type="file" name="photo" class="form-control">

<button class="btn btn-primary mt-3" name="save">Save Book</button>

</form>
</div>

<?php include "footer.php"; ?>
