<?php
include "header.php";
include "sidebar.php";

$id = $_GET['id'];

$book = mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM books WHERE id=$id"));

if(isset($_POST['update'])){

mysqli_query($conn,"UPDATE books SET 
book_name='$_POST[name]',
author='$_POST[author]',
publication='$_POST[pub]',
branch='$_POST[branch]',
quantity='$_POST[qty]'
WHERE id=$id");

echo "<script>alert('Book Updated');window.location='view_books.php';</script>";
}
?>

<div class="form-card">
<h4>Edit Book</h4>

<form method="post">

<input class="form-control" name="name" value="<?=$book['book_name']?>">
<input class="form-control mt-2" name="author" value="<?=$book['author']?>">
<input class="form-control mt-2" name="pub" value="<?=$book['publication']?>">
<input class="form-control mt-2" name="branch" value="<?=$book['branch']?>">
<input class="form-control mt-2" name="qty" value="<?=$book['quantity']?>">

<button class="btn btn-primary mt-3" name="update">Update</button>

</form>
</div>

<?php include "footer.php"; ?>
